document.querySelector("html").style.fontFamily = "sans-serif";
const table1 = document.getElementsByClassName("mytable");
table1.style.borderCollapse = "collapse";
table1.style.border = "2px solid rgb(200,200,200)";
table1.style.letterSpacing = "1px";
table1.style.fontSize = "0.8rem";
table1.style.opacity = "0.5";
